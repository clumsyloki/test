type format = {
    [key: string]: any;
};

export const addresses: format = {
  infoContractAddress:"0xD59f783B8084c7972E766401B6891b97Ceb2e885"
};
