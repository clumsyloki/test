import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import InfoContract from './Components/InfoContract';
import Tes from './Tes';

const App = () => {
  return (
    <div >
      <Tes/>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<InfoContract />} />
          <Route index element={<InfoContract />} />
          <Route path="/home" element={<Tes />}>
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App