import React, { useEffect } from 'react'
import infocontractabi from "../ABIS/Info.json"
import { addresses } from '../Address/addresses'
import { methodByCall } from '../Modules/contractMethodsCall'
import { useSelector, useDispatch } from "react-redux";
import { decrement, increment } from '../Redux/Reducers/counterSlice';

const InfoContract = () => {
    const count = useSelector((state: any) => state.counter);
    console.log(count);
    const dispatch = useDispatch();
     
    const infoAbi = infocontractabi.abi
    const { infoContractAddress } = addresses

    const callgetmethod = async () => {
        const results = await methodByCall(infoAbi, infoContractAddress)
        const p=await results.get().call()
      console.log(p);
    }

    useEffect(() => {
        callgetmethod()
    }, [])
    return (
        <div>InfoContractkk
            <button onClick={() => dispatch(increment())}>Increment</button>
            <button onClick={() => dispatch(decrement())}>Decrement</button>
            
        </div>
    )
}

export default InfoContract