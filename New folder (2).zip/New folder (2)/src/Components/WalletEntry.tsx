import { createWeb3Modal, defaultWagmiConfig } from '@web3modal/wagmi/react'

import { WagmiConfig, configureChains, createConfig } from 'wagmi'
import {  mainnet,goerli,bscTestnet } from 'wagmi/chains'
import WalletService from './WalletService'
import { w3mProvider,w3mConnectors, } from '@web3modal/ethereum'
import { EthereumProvider } from '@walletconnect/ethereum-provider'
import { addresses } from '../Address/addresses'
import infocontractabi from "../ABIS/Info.json"
const { Web3 } = require('web3');

// 1. Get projectId
const projectId = '020d6ba649c0aa901cb2a80f88653fd2'

// 2. Create wagmiConfig
const metadata = {
  name: 'Web3Modal',
  description: 'Web3Modal Example',
  url: 'https://web3modal.com',
  icons: ['https://avatars.githubusercontent.com/u/37784886']
}
//add more in case u want to work with them
const chains = [mainnet,goerli,bscTestnet]
const {publicClient}=configureChains(chains,[w3mProvider({projectId})])


const calllme=async()=>{
  
  const provider = await EthereumProvider.init({
    projectId: '020d6ba649c0aa901cb2a80f88653fd2', // required
    chains: [5], // required
    showQrModal: true // requires @walletconnect/modal
  })
  console.log("provider",publicClient);
  

   const web3 =await new Web3(provider);
  
  const { infoContractAddress } = addresses
  const infoAbi = infocontractabi.abi

  const result = await new web3.eth.Contract(infoAbi, infoContractAddress)
  const fc=await result._methods.get().call()
console.log("errs",fc);

  {
  
  //const pp=  returnProvider()
  
 
//   const web3 = new Web3(pp);
//   console.log("web",web3.providers);
//   const { infoContractAddress } = addresses
//   const infoAbi = infocontractabi.abi

//   const result = await new web3.eth.Contract(infoAbi, infoContractAddress)
//   const fc=await result._methods.get().call()
// console.log("errs",fc);
 }

 }
 //calllme()

const wagmiConfig = defaultWagmiConfig({ chains, projectId, metadata })

const wc:any=createConfig({
  autoConnect:true,
  connectors:w3mConnectors({projectId,chains}),
  publicClient
})
console.log("create config",wc);

// 3. Create modal
const obj=createWeb3Modal({ wagmiConfig, projectId, chains })
console.log("create web3  modal",obj);

const WalletEntry = () => {
  
  
  return (
    <WagmiConfig config={wagmiConfig}>
    <WalletService  />
  </WagmiConfig>
  )
}

export default WalletEntry