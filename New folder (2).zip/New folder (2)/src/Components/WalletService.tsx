import React from 'react'
import { useWeb3Modal,useWeb3ModalState } from '@web3modal/wagmi/react'
import "../index.css";
import { useAccount } from 'wagmi'
import { returnProvider } from '../Modules/UniversalProvider';
import { addresses } from '../Address/addresses';
import infocontractabi from "../ABIS/Info.json"
import { EthereumProvider } from '@walletconnect/ethereum-provider'


const ethers = require("ethers")
const { Web3 } = require('web3');


const WalletService = () => {
    const { open } = useWeb3Modal()
    const {  selectedNetworkId } = useWeb3ModalState()
    const { address,connector, } = useAccount()
    
  console.log("ethers",ethers);
  

    
    const disconnectwallet=()=>{
        if(connector)
        {
            connector?.disconnect()
            window.location.reload()
        }
    }
 const calllme=async()=>{
  
  const provider = await EthereumProvider.init({
    projectId: '020d6ba649c0aa901cb2a80f88653fd2', // required
    chains: [5], // required
    showQrModal: true // requires @walletconnect/modal
  })
  console.log("provider",provider);
  // const pp=  returnProvider()
const web3Provider = new ethers.providers.Web3Provider(provider);


   const web3 =await new Web3(web3Provider);
  
  const { infoContractAddress } = addresses
  const infoAbi = infocontractabi.abi

  const result = await new web3.eth.Contract(infoAbi, infoContractAddress)
  const fc=await result._methods.get().call()
console.log("errs",fc);

  {
  
  //const pp=  returnProvider()
  
 
//   const web3 = new Web3(pp);
//   console.log("web",web3.providers);
//   const { infoContractAddress } = addresses
//   const infoAbi = infocontractabi.abi

//   const result = await new web3.eth.Contract(infoAbi, infoContractAddress)
//   const fc=await result._methods.get().call()
// console.log("errs",fc);
 }

 }
 calllme()
    


  return (
    <div>
        <w3m-button balance="show" label='Connect to Metamask' />
        <button className="button primary-button" onClick={()=>{open({ view: 'Account' })}}>Accounts</button>
      <p>  {selectedNetworkId}</p>
       <p> {address}</p>
    <button className="button primary-button" onClick={disconnectwallet}> Disconnect</button>
    </div>
  )
}

export default WalletService
//jkn