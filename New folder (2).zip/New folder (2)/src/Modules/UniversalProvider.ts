import UniversalProvider from "@walletconnect/universal-provider";
const ethers = require("ethers")
export const returnProvider=async()=>{

console.log("called 1");

//  Initialize the provider
const provider = await UniversalProvider.init({
  logger: "info",
  relayUrl: "ws://<relay-url>",
  projectId: "020d6ba649c0aa901cb2a80f88653fd2",
  metadata: {
    name: "React App",
    description: "React App for WalletConnect",
    url: "https://walletconnect.com/",
    icons: ["https://avatars.githubusercontent.com/u/37784886"],
  },
});

//  create sub providers for each namespace/chain
// await provider.connect({
//     namespaces: {
//       eip155: {
//         methods: [
//           "eth_sendTransaction",
//           "eth_signTransaction",
//           "eth_sign",
//           "personal_sign",
//           "eth_signTypedData",
//         ],
//         chains: ["eip155:80001"],
//         events: ["chainChanged", "accountsChanged"],
//         rpcMap: {
//           80001:
//             "https://rpc.walletconnect.com?chainId=eip155:80001&projectId=<your walletconnect project id>",
//         },
//       },
//     },
//   });

// const web3Provider = new ethers.providers.Web3Provider(provider);
//console.log("web3Provider",web3Provider)



return provider


}