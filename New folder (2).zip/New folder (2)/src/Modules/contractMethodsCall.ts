import { returnsProvider } from "./provider"
const { Web3 } = require('web3');

export const methodByCall=async(abi:any,contractAddress:string)=>{
    let provider:any =await returnsProvider()
    const web3 = new Web3(provider);
    const result = await new web3.eth.Contract(abi, contractAddress)
    if(result)
    return result._methods
}