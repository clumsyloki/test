const { Web3 } = require('web3');

export const returnsProvider = async () => {
    let { ethereum }: any = window
    let provider = ethereum
    await provider.request({ method: "eth_requestAccounts" });
    return provider;
}