import React, { useEffect, useState } from 'react'
import './index.css';
import { returnsProvider } from './Modules/provider';

const Tes = () => {
    const [msg,setMsg]=useState("")
    const [flag,setFlag]=useState(true)
    const myAddress=  window.ethereum.selectedAddress;

    useEffect(()=>{
        if (typeof window.ethereum !== 'undefined') {
            // MetaMask is installed
            if (window.ethereum.selectedAddress) {
              // User is connected
              setMsg('MetaMask is installed and connected, ');
            } else {
              // User is not connected
              setMsg('MetaMask is installed but not connected, ');
            }
          } else {
            // MetaMask is not installed
            setMsg('MetaMask is not installed, ');
          }
    },[window.ethereum,flag])

  


   const buttonClicked=async()=>{
    const provider=await returnsProvider()
    
    provider.request({ method: 'eth_requestAccounts' })
    .then(() => {
      console.log('MetaMask is connected and accounts are accessible.');
    })
    .catch((error) => {
      console.error(error);
    });
    setFlag(!flag)

   }

    return (
        <div className='connectMetamask'>
            <p style={{color:"white"}}>{msg + myAddress}</p>
<button className="button primary-button" onClick={buttonClicked}>Connect Metamask</button>
        </div>
    )
}

export default Tes